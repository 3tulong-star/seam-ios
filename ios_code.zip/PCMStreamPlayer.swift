import AVFoundation

final class PCMStreamPlayer {
    enum Mode { case enqueue, interrupt }

    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()

    private var audioFormat: AVAudioFormat?
    private var isStarted = false

    private var streamToken = UUID()

    func newStreamToken() -> UUID {
        let t = UUID()
        streamToken = t
        return t
    }

    func currentToken() -> UUID { streamToken }

    func startIfNeeded(sampleRate: Double) throws {
        if isStarted {
            if audioFormat?.sampleRate != sampleRate {
                stopAll()
            } else {
                return
            }
        }

        let fmt = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
        audioFormat = fmt

        engine.attach(player)
        engine.connect(player, to: engine.mainMixerNode, format: fmt)

        try engine.start()
        player.play()
        isStarted = true
    }

    func stopAll() {
        player.stop()
        engine.stop()
        isStarted = false
        audioFormat = nil
    }

    func interrupt() {
        _ = newStreamToken()
        player.stop()
        player.reset()
        player.play()
    }

    func enqueuePCM16(base64: String, sampleRate: Double, mode: Mode, token: UUID) {
        guard token == streamToken else { return }

        do { try startIfNeeded(sampleRate: sampleRate) }
        catch { print("PCM player start error:", error); return }

        if mode == .interrupt {
            interrupt()
        }

        guard let fmt = audioFormat else { return }
        guard let data = Data(base64Encoded: base64) else { return }
        if data.count < 2 { return }

        let sampleCount = data.count / 2
        guard let buffer = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: AVAudioFrameCount(sampleCount)) else { return }
        buffer.frameLength = AVAudioFrameCount(sampleCount)

        data.withUnsafeBytes { raw in
            let int16Ptr = raw.bindMemory(to: Int16.self)
            let out = buffer.floatChannelData![0]
            for i in 0..<sampleCount {
                out[i] = Float(int16Ptr[i]) / 32768.0
            }
        }

        player.scheduleBuffer(buffer, completionHandler: nil)
    }
}

import SwiftUI

@MainActor
final class ConversationViewModel: ObservableObject {
    private let wsURL = URL(string: "wss://tulong.zeabur.app/api/v1/asr/realtime")!
    private let httpBase = URL(string: "https://tulong.zeabur.app")!

    @Published var langA: LangOption = supportedLangs.first(where: { $0.id == "zh" })!
    @Published var langB: LangOption = supportedLangs.first(where: { $0.id == "en" })!

    @Published var autoSpeak: Bool = true
    @Published var isHoldingA = false
    @Published var isHoldingB = false
    @Published var messages: [ChatMessage] = []

    private let wsClient = RealtimeWSClient()
    private let streamer = AudioStreamer()

    private let sse = SSEClient()
    private let pcmPlayer = PCMStreamPlayer()

    private var activeSide: Side? = nil
    private var activeMsgId: UUID? = nil

    init() {
        streamer.onAudioBuffer = { [weak self] base64 in
            self?.wsClient.sendAudio(base64: base64)
        }

        wsClient.onPartialText = { [weak self] text in
            Task { @MainActor in self?.applyPartial(text) }
        }

        wsClient.onFinalText = { [weak self] text in
            Task { @MainActor in await self?.applyFinal(text) }
        }

        wsClient.onError = { msg in
            print("WS error:", msg)
        }
    }

    // MARK: - UI events

    func pressAChanged(_ pressing: Bool) {
        isHoldingA = pressing
        pressing ? start(side: .a) : stop()
    }

    func pressBChanged(_ pressing: Bool) {
        isHoldingB = pressing
        pressing ? start(side: .b) : stop()
    }

    func speakMessage(_ m: ChatMessage) {
        guard let text = m.translated, !text.isEmpty else { return }
        let target = (m.side == .a) ? langB.id : langA.id
        playManualTTS(text: text, lang: target)
    }

    // MARK: - ASR core

    private func start(side: Side) {
        guard activeSide == nil else { return }
        activeSide = side

        let msg = ChatMessage(side: side)
        messages.append(msg)
        activeMsgId = msg.id

        let sourceLang = (side == .a) ? langA.id : langB.id
        print("WS connecting to:", wsURL.absoluteString, "lang:", sourceLang)
        wsClient.connect(url: wsURL, lang: sourceLang)

        do { try streamer.start() }
        catch { print("Audio start error:", error) }
    }

    private func stop() {
        streamer.stop()
        wsClient.finish()
        activeSide = nil
        activeMsgId = nil
    }

    private func applyPartial(_ text: String) {
        guard let id = activeMsgId,
              let idx = messages.firstIndex(where: { $0.id == id }) else { return }
        messages[idx].originalPartial = text
    }

    private func applyFinal(_ text: String) async {
        guard let idx = messages.indices.last else { return }
        messages[idx].originalFinal = text
        messages[idx].originalPartial = ""

        let side = messages[idx].side
        let source = (side == .a) ? langA.id : langB.id
        let target = (side == .a) ? langB.id : langA.id

        do {
            let translated = try await translate(text: text, source: source, target: target)
            messages[idx].translated = translated

            if autoSpeak {
                enqueueAutoTTS(text: translated, lang: target)
            }
        } catch {
            print("translate error:", error)
            messages[idx].translated = "[翻译失败]"
        }
    }

    // MARK: - Translate

    private func translate(text: String, source: String, target: String) async throws -> String {
        let endpoint = httpBase.appendingPathComponent("/api/v1/translate/text")
        var req = URLRequest(url: endpoint)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body: [String: Any] = [
            "text": text,
            "source_lang": source,
            "target_lang": target,
            "stream": false
        ]
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            let s = String(data: data, encoding: .utf8) ?? ""
            throw NSError(domain: "Translate", code: 1, userInfo: [NSLocalizedDescriptionKey: "bad status: \(s)"])
        }

        let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any]
        return (obj?["translation"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    }

    // MARK: - Qwen streaming TTS

    private func ttsStreamURL() -> URL {
        httpBase.appendingPathComponent("/api/v1/tts/stream")
    }

    private func enqueueAutoTTS(text: String, lang: String) {
        Task.detached { [weak self] in
            guard let self else { return }
            await self.streamTTS(text: text, lang: lang, mode: .enqueue)
        }
    }

    private func playManualTTS(text: String, lang: String) {
        Task.detached { [weak self] in
            guard let self else { return }
            await self.streamTTS(text: text, lang: lang, mode: .interrupt)
        }
    }

    private func streamTTS(text: String, lang: String, mode: PCMStreamPlayer.Mode) async {
        let url = ttsStreamURL()

        let token: UUID = await MainActor.run {
            (mode == .interrupt) ? pcmPlayer.newStreamToken() : pcmPlayer.currentToken()
        }

        let body: [String: Any] = [
            "text": text,
            "lang": lang,
            "voice": "Cherry"
        ]

        var sampleRate: Double = 24000

        do {
            try await sse.stream(url: url, body: body) { [weak self] event in
                guard let self else { return }
                guard let data = event.dataLine.data(using: .utf8),
                      let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                else { return }

                if let output = obj["output"] as? [String: Any],
                   let audio = output["audio"] as? [String: Any],
                   let b64 = audio["data"] as? String {

                    if let sr = audio["sample_rate"] as? Double { sampleRate = sr }
                    else if let sr = audio["sample_rate"] as? Int { sampleRate = Double(sr) }

                    DispatchQueue.main.async {
                        self.pcmPlayer.enqueuePCM16(
                            base64: b64,
                            sampleRate: sampleRate,
                            mode: mode,
                            token: token
                        )
                    }
                }
            }
        } catch {
            print("TTS stream error:", error.localizedDescription)
        }
    }
}
